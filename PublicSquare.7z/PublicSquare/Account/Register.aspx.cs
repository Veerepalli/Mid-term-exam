﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Membership.OpenAuth;
using System.Data.SqlClient;

public partial class Account_Register : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        
            connection = new SqlConnection(connStr);
            connection.Open();
            SqlTransaction trans = connection.BeginTransaction();
            String queryString = "select count(*) from Registration where UserName(ConnectionString:ConnectionStrings)";
            SqlCommand command = new SqlCommand(queryString, connection);
            command.Transaction = trans;
            command.ExecuteNonQuery();
            command = new SqlCommand(queryString, connection);
            command.Transaction = trans;
            command.ExecuteNonQuery();
            trans.Commit();
        
   

    protected void RegisterUser_CreatedUser(object sender, EventArgs e)
    {
        SqlConnection = null;
        try
        {
            connection = new SqlConnection(connStr);
            connection.Open();
            SqlTransaction trans = connection.BeginTransaction();
            String queryString = "INSERT SOME STUFF";
            SqlCommand command = new SqlCommand(queryString, connection);
            command.Transaction = trans;
            command.ExecuteNonQuery();
            queryString = "INSERT SOME OTHER STUFF";
            command = new SqlCommand(queryString, connection);
            command.Transaction = trans;
            command.ExecuteNonQuery();
            trans.Commit();
        }
        catch (Exception ex)
        {
            trans.Rollback();
            errMsg.Text = ex.Message;
        }
        finally
        {
            if (connection != null)
                connection.Close();
        }
     
    }

    public SqlConnection connection { get; set; }

    public string connStr { get; set; }
}